function HomePage () {
  
  return (
    <div>
      SejaDev
    </div>
  )
}

export default HomePage